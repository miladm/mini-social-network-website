# NOTE: We do not provide a whole lot of error checks, do realize if you
# provide an invalid ID or no ID for actions that require one, then there
# will be error messages generated automatically by Rails!

class StudentsController < ApplicationController
  # GET /students/index
  def index
    @students = Student.all
  end

  # GET /students/:id
  def show
    @student = Student.find(params[:id])
  end

  # GET /students/new
  def new
    @student = Student.new
  end

  # GET /students/edit/:id
  def edit
    @student = Student.find(params[:id])
  end

  # POST /students/
  def create
    @student = Student.new(student_params(params[:student]))
    if @student.save
      redirect_to(@student, notice: "Student created successfully!")
    else
      render :new
    end
  end

  # PATCH /students/:id
  def update
    @student = Student.find(params[:id])
    if @student.update(student_params(params[:student]))
      redirect_to(@student, notice: "Student updated successfully!")
    else
      render :edit
    end
  end

  private
  def student_params(params)
    return params.permit(:name, :birth, :gpa, :grad)
  end
end
