class Student < ActiveRecord::Base
  validates :name, :presence => true
  validates_format_of :birth, :with => /\d\d\d\d-\d\d-\d\d/,
                              :message => "must have format YYYY-MM-DD"
  validate :validate_gpa
  validates :gpa, :numericality => true
  validates :grad, :numericality => true

  def validate_gpa
    if gpa.nil? || (gpa < 0) || (gpa > 4.0)
      errors.add(:gpa, "must be between 0.0 and 4.0")
    end
  end
end
