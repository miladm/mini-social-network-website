class LoadData < ActiveRecord::Migration
  def change
    Student.create([
      {:name => 'Anderson', :birth => '1987-10-22', :gpa => 3.9, :grad => 2009},
      {:name => 'Jones', :birth => '1990-04-16', :gpa => 2.4, :grad => 2012},
      {:name => 'Hernandez', :birth => '1989-08-12', :gpa => 3.1, :grad => 2011},
      {:name => 'Chen', :birth => '1990-02-04', :gpa => 3.2, :grad => 2011}
    ])
  end
end
