class CreateStudents < ActiveRecord::Migration
  def change
    create_table :students do |t|
      t.string  :name
      t.date    :birth
      t.float   :gpa
      t.integer :grad
      t.timestamps
    end
  end
end
